import os

import discord
from dotenv import load_dotenv

import random

from discord.ext import commands

from bs4 import BeautifulSoup as bs
from urllib.request import urlopen as ureq

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
client = discord.Client()

def smart_find(text, word):
    if text.startswith(word + " "):
        return True
    if text.endswith(" " + word):
        return True
    if text.find(" " + word + " ") != -1:
        return True
    return False

intents = discord.Intents.default()
intents.members = True
client = commands.Bot(command_prefix='rate ', intents = intents)

@client.event
async def on_message(message):
    file = open("hash_bot_log.txt", "a")

    if message.content == 'rob help':
        embedVar = discord.Embed(title="Help", description="Help Menu", color=0x00ff00)
        embedVar.add_field(name="say", value="Hashinshin says a semi-random quote", inline=False)
        embedVar.add_field(name="rate", value="Hashinshin rates your opgg", inline=False)
        embedVar.add_field(name="gold", value="If you mention gold Hashinshin advertises a certain monster in gold.", inline=False)
        embedVar.add_field(name="face", value="Rob shows you a part of his selfie collection.", inline=False)

        file.write("\n" + (str)(message.author) + " asked help")
        await message.channel.send(embed = embedVar)

    if smart_find(message.content, 'gold') == True:
        file.write("\n" + (str)(message.author) + ' requested gold')
        response = 'Speaking of gold, did you know this awesome guy SUPPORTJNG is gold? Yeah I know right pretty cool.'
        await message.channel.send(response)

    if message.content == 'rob say':
        hashinshin_quotes = ['NERF SINGED NERF SINGED NERF SINGED ', 'RIGHT THROUGH THE COUNTERSTRIKE ']

        file.write("\n" + (str)(message.author) + ' requested quote')
        response = random.choice(hashinshin_quotes)
        await message.channel.send(response * random.randint(1, 5))

    if message.content == 'rob face':
        rob_face = ['https://cdn.discordapp.com/attachments/772865324629753860/773579672243142676/heres-why-hashinshin-was-banned-on-twitch-is-he-really-a-pedophile.png', 'https://cdn.discordapp.com/attachments/772865324629753860/773580080018489354/DsjOxiaXQAA7DGv.jpg', 'https://cdn.discordapp.com/attachments/772865324629753860/773580289535639592/DsoQL80WoAEzoz2.jpg', 'https://cdn.discordapp.com/attachments/772865324629753860/773580579810967582/Elwn7oKWoAUBC8O.jpg', 'https://cdn.discordapp.com/attachments/772865324629753860/773581028069474355/Ej5XoCdXcAEnLoU.jpg', 'https://cdn.discordapp.com/attachments/772865324629753860/773581185111687179/EjkPzu8XcAIR1RZ.jpg']
        file.write("\n" + (str)(message.author) + ' requested face')
        response = random.choice(rob_face)
        await message.channel.send(response)
    
    if smart_find(message.content, "rate"):

        content_rate = message.content

        opgg_er = content_rate.replace("rate ", "")

        opgg = 'https://euw.op.gg/summoner/userName=+' + (str)(opgg_er)
        file.write("\n" + (str)(message.author) + ' requested rate for ' + (str)(opgg_er))

        client_rate = ureq(opgg)
        page_html_rate = client_rate.read()
        client_rate.close()

        ranked_points = 0

        page_soup_rate = bs(page_html_rate, "html.parser")
        rank = page_soup_rate.find("div", class_="TierRank").text

        if smart_find(rank, 'Iron'):
                ranked_points = 0
        elif smart_find(rank, 'Bronze'):
            ranked_points = 4
        elif smart_find(rank, 'Silver'):
            ranked_points = 8
        elif smart_find(rank, 'Gold'):
            ranked_points = 12
        elif smart_find(rank, 'Platinum'):
            ranked_points = 16
        elif smart_find(rank, 'Diamond'):
            ranked_points = 20
        elif rank == 'Master':
            ranked_points = 24
        elif rank == 'Grandmaster':
            ranked_points = 28
        elif rank == 'Challenger':
            ranked_points = 32

        if ranked_points < 9:
            response = 'You suck xD'
        elif ranked_points > 9 and ranked_points < 17:
            response = 'You are pretty good :D'
        elif ranked_points > 17 and ranked_points < 25:
            response = 'Wow you are really good :o'
        elif ranked_points > 25:
            response = 'Are you a pro player? : ^ O'

        await message.channel.send(response)

    file.close()

client.run(TOKEN)